document.querySelector('form').addEventListener('submit', function (e) {
  e.preventDefault();
  alert('تم التسجيل بنجاح!');
});
